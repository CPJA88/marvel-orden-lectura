MARVEL · ORDEN DE LECTURA PWA

Versión: 1.0.1
Base: Grand Comics Database, volcado 2026-08-01
Orden principal: 51,002 números
Recopilatorios/ediciones: 10,091

USO
- Es una aplicación web estática. Para que funcione como PWA debe servirse por HTTPS (Cloudflare Pages, Workers, Netlify, GitHub Pages, etc.) o por localhost.
- El progreso se guarda en IndexedDB del dispositivo.
- Usa Ajustes > Exportar progreso para conservar una copia JSON.
- La primera búsqueda global descarga un índice compacto; los números se descargan por décadas y quedan en caché para uso posterior.

CRITERIO
- Orden por fecha de venta GCD cuando existe; en su defecto, estimación documentada en la propia ficha.
- Variantes de portada excluidas como lecturas distintas.
- Reimpresiones etiquetadas y filtrables.
- Recopilatorios/ediciones en sección separada.
- Interfaz en castellano; títulos bibliográficos originales se preservan y se muestran alias españoles conocidos cuando existe una equivalencia consolidada.

OFFLINE COMPLETO
- En Ajustes puedes pulsar «Descargar toda la base para uso offline». La app guardará todos los bloques de datos en la caché del navegador.
